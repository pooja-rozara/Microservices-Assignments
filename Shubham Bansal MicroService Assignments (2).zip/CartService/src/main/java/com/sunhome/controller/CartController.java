package com.sunhome.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.sunhome.dto.CartItem;
import com.sunhome.service.CartService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api("Cart Service")
public class CartController {
	@Autowired
	CartService cartService;
	
	Logger logger=LoggerFactory.getLogger(CartController.class);
	@ApiOperation(value = "Add a product to cart")
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Successfully added to cart"),
		    @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
		    @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
		    @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
	})
	@HystrixCommand(fallbackMethod="addcartfail",commandKey="addToCart",groupKey="CartService")
	@PostMapping(value="/cart/")
	public String addToCart(@ApiParam(value="Cart Item in JSON Format")@RequestBody CartItem item)
	{	logger.info("Inserting "+ item.getProductId()+" and qty:= "+item.getQuantity());
		return cartService.addToCart(item);
	}
	
	public String addcartfail(CartItem item){
		return "error while adding to cart";
		
	}
	
	

}
