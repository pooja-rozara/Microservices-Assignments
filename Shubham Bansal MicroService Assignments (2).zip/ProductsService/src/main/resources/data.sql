INSERT INTO Product (product_id,product_name,price,category) values(102,'iPhone 6s',25000,'Mobile')
INSERT INTO Product (product_id,product_name,price,category) values(101,'Sony earphones',500,'Accesories')
INSERT INTO Product (product_id,product_name,price,category) values(104,'Poco f1',15000,'Mobile')
INSERT INTO Product (product_id,product_name,price,category) values(103,'ROG Phone 2',35000,'Mobile')