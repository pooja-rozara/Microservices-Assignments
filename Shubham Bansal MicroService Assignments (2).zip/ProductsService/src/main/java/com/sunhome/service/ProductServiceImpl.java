package com.sunhome.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunhome.dao.ProductRepository;
import com.sunhome.dto.Product;
import com.sunhome.exceptions.ProductException;
@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepository productDao;

	@Override
	public List<Product> getAllProducts() {
		if(productDao.findAll().size()>0)
		return productDao.findAll();
		else 
			throw new ProductException("Error getting products");
	}

	@Override
	public List<Product> findByName(String name) {
		if(productDao.findByProductNameContaining(name).size()>0)
		return productDao.findByProductNameContaining(name);
		else
			throw new ProductException("No Product found");
	}

	@Override
	public double findPrice(int productId) {
		if(productDao.existsById(productId))
		return productDao.getPriceById(productId);
		else
			throw new ProductException("No product Exist");
	}

	@Override
	public Optional<Product> findById(int id) {
		return productDao.findById(id);
	}

	@Override
	public List<Product> getByCategory(String category) {
		return productDao.findProductByCategory(category);
	}

}
