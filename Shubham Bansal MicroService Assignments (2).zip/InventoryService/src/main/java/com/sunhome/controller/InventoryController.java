package com.sunhome.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.sunhome.service.InventoryService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController

@Api("Inventory Service")
public class InventoryController {
	Logger logger=LoggerFactory.getLogger(InventoryController.class);
	@Autowired
	InventoryService invService;
	
	@GetMapping("/stocks/{productId}")
	@ResponseBody
	@ApiOperation(value = "Get stocks for a Product")
	@HystrixCommand(fallbackMethod = "getStocksFail",groupKey = "Inventory Controller",commandKey = "getStocks")
	public int getStocks(@ApiParam(value="Product ID in String Format")@PathVariable("productId")String productId)
	{ logger.info("Geting stocks for ID -"+ productId);
		return invService.getStocks(Integer.parseInt(productId));
	}
	
	public int getStocksFail(String productId)
	{
		return 0;
	}
	
}
