package com.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunhome.dao.InventoryRespository;
import com.sunhome.exceptions.InventoryException;

@Service
public class InventoryServiceImpl implements InventoryService {
	
	@Autowired
	InventoryRespository invDao;
	
	@Override
	public int getStocks(int productId) {
		if(invDao.existsById(productId))
		return invDao.getStockByProductId(productId);	
		else
			throw new InventoryException(" Product Not present ");
	}

}
