package com.sunhome.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunhome.dto.ProductCatalog;
import com.sunhome.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductCatalogController {
	
	@Autowired
	ProductService prodService;
	
	@GetMapping("/getallcatalog")
	public List<ProductCatalog> getAllProducts()
	{
		return prodService.getAllProducts();
	}
	
	@GetMapping("/getprice/{productId}")
	public double getPrice(@PathVariable int productId)
	{
		return prodService.findPrice(productId);
	}
	
	@GetMapping("/getproductbyid/{productId}")
	public ProductCatalog findById(@PathVariable int productId)
	{
		return prodService.findById(productId);
	}
	@GetMapping("/getproductbyname/{name}")
	public ProductCatalog findByName(@PathVariable String name)
	{
		return prodService.findByName(name);
	}
	
	@GetMapping("/getproductbycategory/{category}")
	public List<ProductCatalog> getByCategory(@PathVariable String category)
	{
		return prodService.getByCategory(category);
	}
}
