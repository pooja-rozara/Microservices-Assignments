package com.sunhome.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sunhome.dto.ProductCatalog;

public interface ProductRepository extends JpaRepository<ProductCatalog,Integer> {
	
//	@Query("select product.price from Product product where product.productId = :id")
//	public double getPriceById(@Param("id") Integer id);
	
	

}
