package com.sunhome.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product_catalog")
public class ProductCatalog {
	
	@Id
	@Column(name="productid")
	private Integer productId;
	@Column(name="productname")
	private String productName;
	@Column(name="productcategory")
	private String productCategory;
	
	
	public ProductCatalog() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductCatalog(Integer productId, String productName, String productCategory) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCategory = productCategory;
	}
	
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productCategory="
				+ productCategory + "]";
	}
	
	
	

}
