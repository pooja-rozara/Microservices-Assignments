package com.sunhome.service;

import java.util.List;

import com.sunhome.dto.ProductCatalog;

public interface ProductService {

	List<ProductCatalog> getAllProducts();
	ProductCatalog findById(int id);
	ProductCatalog findByName(String name);
	double findPrice(int productId);
	List<ProductCatalog> getByCategory(String category);

}
