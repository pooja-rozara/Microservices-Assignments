package com.sunhome.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sunhome.dao.ProductRepository;
import com.sunhome.dto.ProductCatalog;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired(required=true)
	ProductRepository prodRepo;

	@Override
	public List<ProductCatalog> getAllProducts() {
		return prodRepo.findAll();
	}

	@Override
	public ProductCatalog findByName(String name) {
		List<ProductCatalog> productList=prodRepo.findAll();
		ProductCatalog productCatalo=null;
		boolean flag=false;
		for(ProductCatalog product:productList)
		{
			if(product.getProductName().equalsIgnoreCase(name))
			{
				productCatalo=product;
				flag=true;
			}
		}
		if(!flag)
		{
			return null;
		}
		else
		{
			return productCatalo;
		}
	}

	@Override
	public double findPrice(int productId) {
		int price=new RestTemplate().getForObject("http://localhost:9083/product/price/"+productId,Integer.class);
		return price;
	}
	@Override
	public List<ProductCatalog> getByCategory(String category) {
		System.out.println("1");
		List<ProductCatalog> productList=prodRepo.findAll();
		System.out.println("2");
		System.out.println(productList);
		List<ProductCatalog> productListToBeReturned =new ArrayList<ProductCatalog>();;
		System.out.println("3");
		boolean flag=false;
		for(ProductCatalog product:productList)
		{
			System.out.println(product);
			if(product.getProductCategory().equalsIgnoreCase(category))
			{
				productListToBeReturned.add(product);
				System.out.println(productListToBeReturned);
				flag=true;
			}
		}
		if(!flag)
		{
			return null;
		}
		else
		{
			return productListToBeReturned;
		}
	}

	@Override
	public ProductCatalog findById(int id) {
		List<ProductCatalog> productList=prodRepo.findAll();
		System.out.println(productList);
		ProductCatalog productCatalo=null;
		boolean flag=false;
		for(ProductCatalog product:productList)
		{
			if(product.getProductId()==id)
			{
				productCatalo=product;
				flag=true;
			}
		}
		if(!flag)
		{
			return null;
		}
		else
		{
			return productCatalo;
		}
	}

}
