insert into product_catalog (productid,productname,productcategory) values(101,'One Plus','Mobile');
insert into product_catalog (productid,productname,productcategory) values(102,'Mi','Mobile');
insert into product_catalog (productid,productname,productcategory) values(103,'iPhone','Mobile');
insert into product_catalog (productid,productname,productcategory) values(201,'Physics','Book');
insert into product_catalog (productid,productname,productcategory) values(202,'Chemistry','Book');
insert into product_catalog (productid,productname,productcategory)  values(203,'Math','Book');