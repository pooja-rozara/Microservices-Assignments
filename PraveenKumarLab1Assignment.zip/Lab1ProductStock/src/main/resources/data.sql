insert into product_stock values(101,20);
insert into product_stock values(102,30);
insert into product_stock values(103,40);
insert into product_stock values(201,50);
insert into product_stock values(202,60);
insert into product_stock values(203,70);