package com.sunhome.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product_stock")
public class ProductStock {
	
	@Id
	@Column(name = "productid")
	private Integer productId;
	@Column(name = "countofproduct")
	private Integer countOfProduct;
	public ProductStock() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductStock(Integer productId, Integer countOfProduct) {
		super();
		this.productId = productId;
		this.countOfProduct = countOfProduct;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Integer getCountOfProduct() {
		return countOfProduct;
	}
	public void setCountOfProduct(Integer countOfProduct) {
		this.countOfProduct = countOfProduct;
	}
	@Override
	public String toString() {
		return "ProductStock [productId=" + productId + ", countOfProduct=" + countOfProduct + "]";
	}
	


}
