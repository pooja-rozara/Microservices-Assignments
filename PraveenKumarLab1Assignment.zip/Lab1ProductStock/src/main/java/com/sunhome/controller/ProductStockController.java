package com.sunhome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sunhome.service.ProductStockService;

@RestController
@RequestMapping("/product")
public class ProductStockController {
	
	@Autowired(required = true)
	ProductStockService prodStockService;
	
	@GetMapping("/getcount/{productid}")
	public int getCount(@PathVariable String productid)
	{
		return prodStockService.getAvailibilityCount(Integer.parseInt(productid));
	}
	
	@PostMapping("/setremainingproduct/{productid}/{count}")
	public void setRemainingProduct(@PathVariable Integer productid,@PathVariable Integer count )
	{
		prodStockService.setRemainingProduct(productid,count);
	}
	
}
