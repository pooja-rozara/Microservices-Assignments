package com.sunhome.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sunhome.dto.ProductStock;

public interface ProductStockRepository extends JpaRepository<ProductStock,Integer> {
	
	

}
