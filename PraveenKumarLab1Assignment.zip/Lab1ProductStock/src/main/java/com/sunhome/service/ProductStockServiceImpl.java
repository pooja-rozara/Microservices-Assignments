package com.sunhome.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunhome.dao.ProductStockRepository;
import com.sunhome.dto.ProductStock;

@Service
public class ProductStockServiceImpl implements ProductStockService{
	
	@Autowired
	ProductStockRepository prodStockRepo;

	@Override
	public int getAvailibilityCount(Integer productId) {
		List<ProductStock> productStockList=prodStockRepo.findAll();
		int stockCount=0;
		boolean flag=false;
		for(ProductStock product:productStockList)
		{
			System.out.println(product);
			if(product.getProductId().equals(productId))
			{System.out.println(product.getCountOfProduct());
				stockCount=product.getCountOfProduct();
				flag=true;
			}
		}
		if(!flag)
		{
			return 0;
		}
		else
		{
			return stockCount;
		}
	}

	@Override
	public void setRemainingProduct(Integer productid,Integer count) {
		
		List<ProductStock> productStockList=prodStockRepo.findAll();
	
		for(ProductStock product:productStockList)
		{
			if(product.getProductId().equals(productid))
			{
				product.setCountOfProduct(count);
				prodStockRepo.saveAndFlush(product);
			}
		}	
	}

	

}
