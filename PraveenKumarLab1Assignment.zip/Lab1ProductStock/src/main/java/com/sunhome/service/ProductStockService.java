package com.sunhome.service;

import org.springframework.web.bind.annotation.PathVariable;

public interface ProductStockService {
	
	 int getAvailibilityCount(Integer productId);
	 void setRemainingProduct(Integer productid, Integer count);

}
