package com.sunhome.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sunhome.dto.ProductCart;

public interface ProductCartRepository extends JpaRepository<ProductCart,Integer> {
	
	

}
