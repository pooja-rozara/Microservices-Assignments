package com.sunhome.service;

import java.util.List;

import com.sunhome.dto.ProductCart;

public interface ProductCartService {
	
	ProductCart addToCart(ProductCart product);
    List<ProductCart> getAllCartItem();
}
