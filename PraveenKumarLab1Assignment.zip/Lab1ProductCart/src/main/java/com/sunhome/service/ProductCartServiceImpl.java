package com.sunhome.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sunhome.dao.ProductCartRepository;
import com.sunhome.dto.ProductCart;

@Service
public class ProductCartServiceImpl implements ProductCartService{
	
	@Autowired
	ProductCartRepository prodStockRepo;

	@Override
	public ProductCart addToCart(ProductCart product) {
		int count=new RestTemplate().getForObject("http://localhost:9083/product/getcount/"+product.getProductId(),Integer.class);
        if(product.getCountOfProduct()<count)
        {
        	return prodStockRepo.save(product);
        }
        else
        {
        	return null;
        }
	}

	@Override
	public List<ProductCart> getAllCartItem() {
		
		return prodStockRepo.findAll();
	}

	

	

}
