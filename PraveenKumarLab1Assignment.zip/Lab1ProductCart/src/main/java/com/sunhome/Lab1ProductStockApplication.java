package com.sunhome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab1ProductStockApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab1ProductStockApplication.class, args);
	}

}
