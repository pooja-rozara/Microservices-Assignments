package com.sunhome.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product_cart")
public class ProductCart {
	
	@Id
	@Column(name = "productid")
	private Integer productId;
	@Column(name = "countofproduct")
	private Integer countOfProduct;
	@Column(name = "totalprice")
	private Integer totalPrice;
	
	public ProductCart(Integer productId, Integer countOfProduct, Integer totalPrice) {
		super();
		this.productId = productId;
		this.countOfProduct = countOfProduct;
		this.totalPrice = totalPrice;
	}
	public Integer getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Integer totalPrice) {
		this.totalPrice = totalPrice;
	}
	public ProductCart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductCart(Integer productId, Integer countOfProduct) {
		super();
		this.productId = productId;
		this.countOfProduct = countOfProduct;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Integer getCountOfProduct() {
		return countOfProduct;
	}
	public void setCountOfProduct(Integer countOfProduct) {
		this.countOfProduct = countOfProduct;
	}
	@Override
	public String toString() {
		return "ProductStock [productId=" + productId + ", countOfProduct=" + countOfProduct + ", totalPrice="
				+ totalPrice + "]";
	}
	
	


}
