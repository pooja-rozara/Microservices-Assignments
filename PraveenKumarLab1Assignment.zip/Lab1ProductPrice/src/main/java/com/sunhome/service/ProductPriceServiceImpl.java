package com.sunhome.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunhome.dao.ProductPriceRepository;
import com.sunhome.dto.ProductPrice;

@Service
public class ProductPriceServiceImpl implements ProductPriceService{
	
	
	@Autowired(required = true)
	ProductPriceRepository prodPriceRepo;

	@Override
	public double getPrice(int productId) {
		List<ProductPrice> productPriceList=prodPriceRepo.findAll();
		int productPrice=0;
		boolean flag=false;
		for(ProductPrice product:productPriceList)
		{
			System.out.println(product);
			if(product.getProductId().equals(productId))
			{System.out.println(product.getProductPrice());
			productPrice=product.getProductPrice();
				flag=true;
			}
		}
		if(!flag)
		{
			return 0;
		}
		else
		{
			return productPrice;
		}
	}

}
