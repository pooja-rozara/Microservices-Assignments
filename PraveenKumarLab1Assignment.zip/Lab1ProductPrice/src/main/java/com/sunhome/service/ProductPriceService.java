package com.sunhome.service;


public interface ProductPriceService {
	
	public double getPrice(int productId);

}
