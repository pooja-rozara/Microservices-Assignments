package com.sunhome.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sunhome.dto.ProductPrice;

@Repository
public interface ProductPriceRepository extends JpaRepository<ProductPrice,Integer> {
	
	
//	@Query("SELECT price.productprice from product_price price where price.productid= :id")
//	int getPrice(@Param("id")int productId);
	

}
