package com.sunhome.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product_price")
public class ProductPrice {
	
	@Id
	@Column(name="productid")
	private Integer productId;
	@Column(name="productprice")
	private Integer productPrice;
	public ProductPrice(Integer productId, Integer productPrice) {
		super();
		this.productId = productId;
		this.productPrice = productPrice;
	}
	public ProductPrice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Integer getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Integer productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "ProductPrice [productId=" + productId + ", productPrice=" + productPrice + "]";
	}
	
	


}
