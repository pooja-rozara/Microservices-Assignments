insert into product_price (productid,productprice) values(101,20000);
insert into product_price (productid,productprice) values(102,15000);
insert into product_price (productid,productprice) values(103,25000);
insert into product_price (productid,productprice) values(201,200);
insert into product_price (productid,productprice) values(202,250);
insert into product_price (productid,productprice) values(203,300);