package com.sunhome.services;

import com.sunhome.entities.Cart;
import com.sunhome.entities.Product;
import com.sunhome.exceptions.CartNotFoundException;

public interface ICartService {
    public Cart addToCart(int cartId,Product product,int quantity) throws CartNotFoundException;
    public Cart createNewCart();
    public Cart getCartWithId(int cartId) throws CartNotFoundException;
}
