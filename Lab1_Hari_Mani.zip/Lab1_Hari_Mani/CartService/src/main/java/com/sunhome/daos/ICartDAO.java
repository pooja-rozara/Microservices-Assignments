package com.sunhome.daos;

import com.sunhome.entities.Cart;
import org.springframework.data.repository.CrudRepository;

public interface ICartDAO extends CrudRepository<Cart,Integer> {
}
