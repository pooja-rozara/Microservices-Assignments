package com.sunhome.controllers;

import com.sunhome.dtos.CartDTO;
import com.sunhome.dtos.ItemDTO;
import com.sunhome.entities.Cart;
import com.sunhome.entities.Item;
import com.sunhome.entities.Product;
import com.sunhome.exceptions.CartNotFoundException;
import com.sunhome.services.ICartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Set;

@RestController
public class CartController {
    @Autowired
    DiscoveryClient discoveryClient;
    @Autowired
    ICartService cartService;

    @PostMapping(
            value="/cart/add",
            produces = "application/json",
            headers = "Accept=application/json"
    )
    public CartDTO addItemToCart(@RequestBody ItemDTO itemToBeAdded) throws CartNotFoundException {
        RestTemplate restTemplate = new RestTemplate();
        List<ServiceInstance> productService = discoveryClient.getInstances("product-service");
        String productServiceURI = productService.get(0).getUri().toString()+"?id="+itemToBeAdded.getProductId();
        ResponseEntity<Product> productWithId =  restTemplate.getForEntity(productServiceURI, Product.class);
        Cart updatedCart =  cartService.addToCart(itemToBeAdded.getCartId(),productWithId.getBody(),itemToBeAdded.getQuantity());
        return new CartDTO(updatedCart.getCartId());
    }

    @GetMapping(
            value="/cart",
            produces = "application/json"
    )
    public Set<Item> getItemsInCart(@RequestParam("id") int cartId) throws CartNotFoundException{
        return cartService.getCartWithId(cartId).getItems();
    }

    @PostMapping(
            value="/cart/new"
    )
    public CartDTO createNewCart(){
        return new CartDTO(cartService.createNewCart().getCartId());
    }
}
