package com.sunhome.services;

import com.sunhome.daos.ICartDAO;
import com.sunhome.daos.ICartItemDAO;
import com.sunhome.entities.Cart;
import com.sunhome.entities.Item;
import com.sunhome.entities.Product;
import com.sunhome.exceptions.CartNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Optional;

@Service
@Transactional
public class CartServiceImpl implements ICartService{
    @Autowired
    private ICartDAO cartDAO;
    @Autowired
    private ICartItemDAO cartItemDAO;
    @Override
    public Cart addToCart(int cartId,Product product, int quantity) throws CartNotFoundException {
        Optional<Cart> cartWithId = cartDAO.findById(cartId);
        if(cartWithId.isPresent()) {
            Cart cart = cartWithId.get();
            Item item = this.createCartItem(product, quantity);
            cartItemDAO.save(item);
            if (cart == null) {
                cart = new Cart();
            }
            cart.getItems().add(item);
            cart = cartDAO.save(cart);
            return cart;
        }
        throw new CartNotFoundException("No cart was found with cart_id:"+cartId);
    }

    @Override
    public Cart createNewCart() {
        Cart newCart = new Cart();
        cartDAO.save(newCart);
        return newCart;
    }

    @Override
    public Cart getCartWithId(int cartId) throws CartNotFoundException {
        Optional<Cart> cartWithId = cartDAO.findById(cartId);
        if(cartWithId.isPresent()){
            return cartWithId.get();
        }
        throw new CartNotFoundException("No cart was found with cart_id:"+cartId);
    }

    public Item createCartItem(Product product, int quantity){
        Item newItem = new Item(product,quantity);
        newItem = cartItemDAO.save(newItem);
        return newItem;
    }

}
