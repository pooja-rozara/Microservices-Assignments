package com.sunhome.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
@Entity
@Table(name="cart")
public class Cart implements Serializable {
    private static final long serialVersionUID=2222L;
    @Id
    @GeneratedValue()
    private int cartId;
    @OneToMany
    @JoinTable(
            name = "cart_item",
            joinColumns = {@JoinColumn(name="cart_id")},
            inverseJoinColumns = {@JoinColumn(name="item_id")}
    )
    private Set<Item> items;

    @Transient
    public float getCartValue(){
        float cartValue = 0;
        for(Item item: items){
            cartValue+=item.getItemValue();
        }
        return  cartValue;
    }

    public Cart(int cartId, Set<Item> items) {
        this.cartId = cartId;
        this.items = items;
    }

    public Cart() {
        items = new HashSet<>();
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public Set<Item> getItems() {
        return items;
    }

    public void setItems(Set<Item> items) {
        this.items = items;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj == null) return false;
        if (this == obj) return true;
        if (!(obj instanceof Cart)) return false;
        Cart cart = (Cart) obj;
        return getCartId() == cart.getCartId();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCartId());
    }
}
