package com.sunhome.dtos;

public class CartDTO {
    private int cartId;

    public CartDTO(int cartId) {
        this.cartId = cartId;
    }

    public CartDTO() {
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

}
