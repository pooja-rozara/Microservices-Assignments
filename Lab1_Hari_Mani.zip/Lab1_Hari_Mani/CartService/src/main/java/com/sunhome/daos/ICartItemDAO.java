package com.sunhome.daos;

import com.sunhome.entities.Item;
import org.springframework.data.repository.CrudRepository;

public interface ICartItemDAO extends CrudRepository<Item,Integer> {
}
