INSERT INTO product(product_name,product_category,product_price)
VALUES('Samsung Galaxy s9','Mobile Phone',35000.0);
INSERT INTO product(product_name,product_category,product_price)
VALUES('Huawei Honor 9i','Mobile Phone',20000.0);
INSERT INTO product(product_name,product_category,product_price)
VALUES('Xiaomi Poco F1','Mobile Phone',25000.0);
INSERT INTO product(product_name,product_category,product_price)
VALUES('Echo Park','Book',350.0);
INSERT INTO product(product_name,product_category,product_price)
VALUES('Art of War','Book',200.0);
INSERT INTO product(product_name,product_category,product_price)
VALUES('Pigeon Mixer','Home Appliance',1250.0);
INSERT INTO product(product_name,product_category,product_price)
VALUES('Havells Fan','Home Appliance',1500.0);
