DROP TABLE IF EXISTS product;
CREATE TABLE product(
    product_id INTEGER PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(30) NOT NULL,
    product_category VARCHAR(30) NOT NULL,
    product_price DECIMAL(10,2) NOT NULL
);