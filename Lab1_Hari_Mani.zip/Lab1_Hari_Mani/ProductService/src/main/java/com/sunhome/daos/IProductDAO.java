package com.sunhome.daos;

import com.sunhome.entities.Product;
import org.springframework.data.repository.CrudRepository;

public interface IProductDAO extends CrudRepository<Product,Integer> {
}
