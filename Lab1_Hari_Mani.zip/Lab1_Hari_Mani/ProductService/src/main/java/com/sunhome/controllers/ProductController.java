package com.sunhome.controllers;

import com.sunhome.entities.Product;
import com.sunhome.exceptions.ProductNotFoundException;
import com.sunhome.services.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProductController {
    @Autowired
    private IProductService productService;

    @GetMapping(
            value = "/products",
            produces = "application/json"
    )
    public List<Product> getAllProducts(){
        return productService.getAllProducts();
    }

    @GetMapping(
            value = "/product",
            produces = "application/json"
    )
    public Product getProductWithId(@RequestParam("id") int productId) throws ProductNotFoundException {
        return productService.getProductWithId(productId);
    }
}
