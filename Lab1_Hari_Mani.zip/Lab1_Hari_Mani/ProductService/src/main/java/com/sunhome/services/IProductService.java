package com.sunhome.services;

import com.sunhome.entities.Product;
import com.sunhome.exceptions.ProductNotFoundException;

import java.util.List;

public interface IProductService {
    public List<Product> getAllProducts();
    public Product getProductWithId(int productId) throws ProductNotFoundException;
}
