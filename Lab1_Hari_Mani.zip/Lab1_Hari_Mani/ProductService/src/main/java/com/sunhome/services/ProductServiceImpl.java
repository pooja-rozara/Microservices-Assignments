package com.sunhome.services;

import com.sunhome.daos.IProductDAO;
import com.sunhome.entities.Product;
import com.sunhome.exceptions.ProductNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements IProductService {
    @Autowired
    IProductDAO productDAO;
    @Override
    public List<Product> getAllProducts() {
        return (List<Product>)productDAO.findAll();
    }

    @Override
    public Product getProductWithId(int productId) throws ProductNotFoundException {
        Optional<Product> productWithId = productDAO.findById(productId);
        if(productWithId.isPresent()){
            return productWithId.get();
        }
        throw new ProductNotFoundException("No product found with product_id:"+productId);
    }
}
