package com.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;


import com.sunhome.dao.CartItemRepository;
import com.sunhome.dto.CartItem;
import com.sunhome.exception.NoEnoughResources;
@Service
public class CartServiceImpl implements CartService {
	
@Autowired
CartItemRepository cartDao;
@Autowired
RestTemplate restTemplate;


	@Override
	@Transactional
	public String addToCart(CartItem item) {
		double cartValue=0;
		if(item.getQuantity()<new RestTemplate().getForObject("http://localhost:8081/stocks/"+item.getProductId(),Integer.class))
		{
			cartDao.save(item);
			
			//dao.AddData(item);
			for(CartItem temp:cartDao.findAll())
			{
				cartValue+=(temp.getQuantity()*(restTemplate.getForObject("http://products-service/products/price/id="+temp.getProductId(), Double.class)));
			}
			return "Total Cart amount is: Rs. "+cartValue;
			
		}
		else
			throw new NoEnoughResources("Not sufficient Units");
	}
	

}
