package com.sunhome.cotroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.sunhome.dto.CartItem;
import com.sunhome.service.CartService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@Api
public class CartController {
	@Autowired
	CartService cartService;
	
	@PostMapping(value="/cart/")
	@ResponseBody
	@HystrixCommand(fallbackMethod = "whenExceptionOccured",commandKey = "addToCart",groupKey = "CartController")
	@ApiOperation(value="Adding Product to Cart")
	public String addToCart(@ApiParam(value="product value in json")@RequestBody CartItem item)
	{
		return cartService.addToCart(item);
	}
	public String whenExceptionOccured(CartItem item)
	{
		return "Error While Addng to Cart";
	}
	

}
