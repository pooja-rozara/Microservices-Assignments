package com.sunhome.exception;

public class NoEnoughResources extends RuntimeException{
public NoEnoughResources(String message)
{
	super(message);
}
public NoEnoughResources(String message,Throwable t)
{
	super(message,t);
}
}
