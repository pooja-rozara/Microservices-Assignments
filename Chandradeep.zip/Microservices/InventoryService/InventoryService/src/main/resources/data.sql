INSERT INTO inventory(product_id,available_units) values (102,500); 
INSERT INTO inventory(product_id,available_units) values (101,50); 
INSERT INTO inventory(product_id,available_units) values (103,900); 
INSERT INTO inventory(product_id,available_units) values (104,5); 