package com.sunhome.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sunhome.dto.Inventory;
@Repository
public interface InventoryRespository extends JpaRepository<Inventory, Integer> {
	
	@Query("SELECT inv.availableUnits from Inventory inv where inv.productId= :id")
	int getStockByProductId(@Param("id")int productId);
	
	
	
}
