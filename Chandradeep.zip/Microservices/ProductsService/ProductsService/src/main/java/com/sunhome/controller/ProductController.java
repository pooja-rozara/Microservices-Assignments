package com.sunhome.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sunhome.dto.Product;
import com.sunhome.service.ProductService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@Api
public class ProductController {
	
	@Autowired
	ProductService prodService;
	
	@GetMapping(value="/products/search={name}")
	@ResponseBody
	@ApiOperation(value="Searching product By Name")
	public List<Product> searchProduct(@ApiParam(value="takes name as parameter")@PathVariable("name")String name)
	{
		return prodService.findByName(name);
	}
	
	
	@GetMapping(value="/products/price/id={id}")
	@ResponseBody
	@ApiOperation(value="Fetching Price of a product by id")
	public double getPrice(@ApiParam(value="takes productId as parameter")@PathVariable("id")String id)
	{
		return prodService.findPrice(Integer.parseInt(id));
	}
	
	
	@GetMapping(value="/products")
	@ResponseBody
	@ApiOperation(value="Fetching all the available products")
	public List<Product> getAllProducts()
	{
		return prodService.getAllProducts();
	}
	
	@GetMapping(value="/products/{id}")
	@ResponseBody
	@ApiOperation(value="Fetching Product  by id")
	public Optional<Product> getProduct(@ApiParam(value="takes id as parameter")@PathVariable("id")String id)
	{
		return prodService.findById(Integer.parseInt(id));
	}
	
	@GetMapping(value="/products/category={cat}")
	@ResponseBody
	@ApiOperation(value="Fetching products by Category")
	public List<Product> getProductByCategory(@ApiParam(value="takes category as parameter")@PathVariable("cat")String category)
	{
		return prodService.getByCategory(category);
	}
	
	
}
