INSERT INTO Product (product_id,product_name,price,category) values(101,'Sony Bravia',35000,'TV')
INSERT INTO Product (product_id,product_name,price,category) values(102,'iPhone 6s',25000,'Mobile')
INSERT INTO Product (product_id,product_name,price,category) values(103,'Sony Xpria',22000,'Mobile')
INSERT INTO Product (product_id,product_name,price,category) values(104,'LG Smart TV',45000,'TV')



