package com.sunhome.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sunhome.dto.Product;
import com.sunhome.service.ProductService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController

@Api("Product Service")
public class ProductController {
	
	@Autowired
	ProductService prodService;
	
	@ApiOperation(value = "Search a Product")
	@GetMapping(value="/products/search={name}")
	@ResponseBody
	public List<Product> searchProduct(@ApiParam(value="Name in string format")@PathVariable("name")String name)
	{
		return prodService.findByName(name);
	}
	
	@ApiOperation(value = "Get Price of Product")
	@GetMapping(value="/products/price/id={id}")
	@ResponseBody
	public double getPrice(@ApiParam(value="Product ID in Int")@PathVariable("id")String id)
	{
		return prodService.findPrice(Integer.parseInt(id));
	}
	
	@ApiOperation(value = "Get all Porducts")
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Successfully retrieved list"),
		    @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
		    @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
		    @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
	})
	@GetMapping(value="/products")
	@ResponseBody
	public List<Product> getAllProducts()
	{
		return prodService.getAllProducts();
	}
	
	@ApiOperation(value = "Get Product from Id")
	@GetMapping(value="/products/{id}")
	@ResponseBody
	public Optional<Product> getProduct(@ApiParam(value="Id in String")@PathVariable("id")String id)
	{
		return prodService.findById(Integer.parseInt(id));
	}
	
	@ApiOperation(value = "Recommendation with category")
	@GetMapping(value="/products/category={cat}")
	@ResponseBody
	public List<Product> getProductByCategory(@ApiParam(value="Category in String")@PathVariable("cat")String category)
	{
		return prodService.getByCategory(category);
	}
	
	
}
