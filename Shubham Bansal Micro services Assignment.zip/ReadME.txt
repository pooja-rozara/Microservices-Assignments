I've used 
1.H2
2.Eureka-Eureka Client
3.Hystrix in cart service
4.Swagger in all services
