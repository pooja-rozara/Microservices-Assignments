package com.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sunhome.dao.CartItemRepository;
import com.sunhome.dto.CartItem;
import com.sunhome.exceptions.CartException;
@Service
public class CartServiceImpl implements CartService {
	
@Autowired
CartItemRepository cartDao;
@Autowired
RestTemplate resttemplate;
	@Override
	public String addToCart(CartItem item) {
		double cartValue=0;
		if(item.getQuantity()<resttemplate.getForObject("http://inventory-service/stocks/"+item.getProductId(),Integer.class))
		{	cartDao.save(item);
			for(CartItem temp:cartDao.findAll())
			{
				cartValue+=(temp.getQuantity()*(resttemplate.getForObject("http://products-service/products/price/id="+temp.getProductId(), Double.class)));
			}
			return "Total Cart amount is: Rs. "+cartValue;
			
		}
		else
			throw new CartException("Insufficient Units");
	}
	

}
