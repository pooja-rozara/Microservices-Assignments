package com.cg.sunhome.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sunhome.dto.Product;
import com.cg.sunhome.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService prodService;
	
	@GetMapping(value="/products/{name}")
	@ResponseBody
	public List<Product> searchProduct(@PathVariable("name")String name)
	{
		return prodService.findByName(name);
	}
	
	@GetMapping(value="/products")
	@ResponseBody
	public List<Product> getAllProducts()
	{
		return prodService.getAllProducts();
	}
	
	@GetMapping(value="/products/id={id}")
	@ResponseBody
	public Optional<Product> getProduct(@PathVariable("id")int id)
	{
		return prodService.findById(id);
	}
	
	@GetMapping(value="/products/name/{id}")
	@ResponseBody
	public String getProductName(@PathVariable("id")int id)
	{
		return prodService.findNameById(id);
	}
	
	@GetMapping(value="/products/category={cat}")
	@ResponseBody
	public List<Product> getProductByCategory(@PathVariable("cat")String category)
	{
		return prodService.getByCategory(category);
	}
	
	
}
