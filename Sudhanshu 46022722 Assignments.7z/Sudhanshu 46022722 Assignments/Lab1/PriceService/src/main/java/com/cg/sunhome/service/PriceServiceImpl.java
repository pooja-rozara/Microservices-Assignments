package com.cg.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sunhome.dao.PriceRepository;

@Service
public class PriceServiceImpl implements PriceService {

	@Autowired
	PriceRepository priceDao;
	
	@Override
	public double findPrice(int productId) {
		return priceDao.getPriceById(productId);
	}
}
