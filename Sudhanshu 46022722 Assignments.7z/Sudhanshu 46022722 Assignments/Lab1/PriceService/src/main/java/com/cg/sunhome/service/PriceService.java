package com.cg.sunhome.service;

public interface PriceService {

	public double findPrice(int productId);
}
