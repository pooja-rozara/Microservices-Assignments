package com.cg.sunhome.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.sunhome.dto.Inventory;

public interface InventoryRepository extends JpaRepository<Inventory, Integer> {
	
	@Query("SELECT inventory.availableUnits from Inventory inventory where inventory.productId= :id")
	int getStockByProductId(@Param("id")int productId);
	
}
