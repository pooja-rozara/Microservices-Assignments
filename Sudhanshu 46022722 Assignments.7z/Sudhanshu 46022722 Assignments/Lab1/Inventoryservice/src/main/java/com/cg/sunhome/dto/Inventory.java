package com.cg.sunhome.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Inventory {
	@Id
	private Integer productId;
	private Integer availableUnits;
	
	public Inventory()
	{
		
	}

	public Inventory(Integer productId, Integer availableUnits) {
		super();
		this.productId = productId;
		this.availableUnits = availableUnits;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getAvailableUnits() {
		return availableUnits;
	}

	public void setAvailableUnits(Integer availableUnits) {
		this.availableUnits = availableUnits;
	}

	@Override
	public String toString() {
		return "Inventory [productId=" + productId + ", availableUnits=" + availableUnits + "]";
	}
	

}
