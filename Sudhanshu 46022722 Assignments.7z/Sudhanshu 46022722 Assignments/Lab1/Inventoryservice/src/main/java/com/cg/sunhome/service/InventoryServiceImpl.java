package com.cg.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sunhome.dao.InventoryRepository;



@Service
public class InventoryServiceImpl implements InventoryService {
	
	@Autowired
	InventoryRepository invDao;
	
	@Override
	public int getStocks(int productId) {
		return invDao.getStockByProductId(productId);	
	}

}
