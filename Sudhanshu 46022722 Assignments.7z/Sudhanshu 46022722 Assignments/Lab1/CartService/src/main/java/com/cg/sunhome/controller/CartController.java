package com.cg.sunhome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sunhome.dto.CartItem;
import com.cg.sunhome.service.CartService;



@RestController
public class CartController {

	
	@Autowired
	CartService cartService;
	
	@PostMapping(value="/cart")
	@ResponseBody
	public String addToCart(@RequestBody CartItem item)
	{
		return cartService.addToCart(item);
	}
}
