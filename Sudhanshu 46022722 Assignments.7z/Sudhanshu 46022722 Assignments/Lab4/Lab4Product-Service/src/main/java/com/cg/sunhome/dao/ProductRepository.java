package com.cg.sunhome.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.sunhome.dto.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
	
	public List<Product> findProductByCategory(String category);

	
	
	List<Product> findByProductNameContaining(String title);
	
	@Query("select product.productName from Product product where product.productId = :id")
	public String findNameById(@Param("id") Integer id);
	
	@Query("select product.category from Product product where product.productId = :id")
	public String getCategoryById(@Param("id") Integer id);
	
	List<Product> findByCategoryIn(List<String> categories);

}
