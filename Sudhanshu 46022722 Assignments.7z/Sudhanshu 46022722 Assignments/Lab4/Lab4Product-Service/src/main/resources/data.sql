INSERT INTO Product (product_id,product_name,category) values(102,'iPhone 6s','Mobile');
INSERT INTO Product (product_id,product_name,category) values(103,'iPhone 7s','Mobile');
INSERT INTO Product (product_id,product_name,category) values(104,'Hp','Laptop');