package com.sunhome.service;

import java.util.List;

import com.sunhome.dto.CartItem;

public interface CartService {
	
	String addToCart(CartItem item);
	List<CartItem> getCart();
	List<String> categories();
}
