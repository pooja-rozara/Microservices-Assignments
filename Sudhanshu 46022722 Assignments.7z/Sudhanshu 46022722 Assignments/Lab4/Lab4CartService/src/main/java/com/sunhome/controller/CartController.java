package com.sunhome.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.bouncycastle.asn1.isismtt.x509.ProcurationSyntax;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.sunhome.config.ProductionConfig;
import com.sunhome.dto.CartItem;
import com.sunhome.dto.Price;
import com.sunhome.dto.Product;
import com.sunhome.service.CartService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api("Cart Service")
public class CartController {
	@Autowired
	CartService cartService;
	
	@Autowired
	RestTemplate rest;
	
	Logger logger=LoggerFactory.getLogger(CartController.class);
	@ApiOperation(value = "Add a product to cart")
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Successfully added to cart"),
		    @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
		    @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
		    @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
	})
	@HystrixCommand(fallbackMethod="addcartfail",commandKey="addToCart",groupKey="CartService")
	@PostMapping(value="/cart/")
	public String addToCart(@ApiParam(value="Cart Item in JSON Format")@RequestBody CartItem item)
	{	logger.info("Inserting "+ item.getProductId()+" and qty:= "+item.getQuantity());
		return cartService.addToCart(item);
	}
	
	public String addcartfail(CartItem item){
		return "error while adding to cart";
		
	}
	
	
	@PostMapping(value="/showcart")
	public ModelAndView addToCartMVC(@ModelAttribute("cartItem")@Valid CartItem item)
	{	logger.info("Inserting "+ item.getProductId()+" and qty:= "+item.getQuantity());
		cartService.addToCart(item);
		List<CartItem> cart=cartService.getCart();
		return new ModelAndView("Cart","cartList",cart);
		
	}
	
	@GetMapping(value="/cartValue")
	public ModelAndView cartValue()
	{	double cartValue=0;
		List<CartItem> cart=cartService.getCart();
		for(CartItem temp:cart)
		{
			cartValue+=(temp.getQuantity()*(rest.getForObject("http://price-service/price/"+temp.getProductId(), Double.class)));
		}
		
		return new ModelAndView("CartValue","value",cartValue);
	}
	
	
	@GetMapping(value="/recommendation")
	public ModelAndView recommedation()
	{	
		List<Product> products=rest.postForObject("http://products-service/products/recommend", cartService.categories(), List.class);
		return new ModelAndView("Recom","myList", products);
	}
	
	
	
	
	@GetMapping(value="/")
	public ModelAndView showData(){
	List<Product> myList=rest.getForObject("http://products-service/products", List.class);
	return new ModelAndView("index","myList", myList);
		
	}
	
	
	@GetMapping(value="/addToCart")
	public ModelAndView updatePage(@RequestParam("id") Integer id,@ModelAttribute("dataprod") CartItem cartItem ){
		
		cartItem.setProductId(id);
		
		return new ModelAndView("Add","cartItem",cartItem);
	}
	
	@GetMapping(value="/viewPrice")
	public ModelAndView updatePrice(@RequestParam("id") Integer id){
		Price myList=rest.getForObject("http://price-service/price/full/"+id, Price.class);
		return new ModelAndView("View","myList", myList);
	}
	
	
	
	

}
