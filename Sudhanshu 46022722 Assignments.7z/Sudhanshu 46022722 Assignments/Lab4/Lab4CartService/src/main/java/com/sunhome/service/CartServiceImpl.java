package com.sunhome.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sunhome.dao.CartItemRepository;
import com.sunhome.dto.CartItem;
import com.sunhome.exceptions.CartException;
@Service
public class CartServiceImpl implements CartService {
	
@Autowired
CartItemRepository cartDao;
@Autowired
RestTemplate resttemplate;
	@Override
	public String addToCart(CartItem item) {
		double cartValue=0;
		if(item.getQuantity()<resttemplate.getForObject("http://inventory-service/stocks/"+item.getProductId(),Integer.class))
		{	cartDao.save(item);
			for(CartItem temp:cartDao.findAll())
			{
				cartValue+=(temp.getQuantity()*(resttemplate.getForObject("http://price-service/price/"+temp.getProductId(), Double.class)));
			}
			return "Total Cart amount is: Rs. "+cartValue;
			
		}
		else
			throw new CartException("Insufficient Units");
	}
	
	
	@Override
	public List<CartItem> getCart() {
		
		return cartDao.findAll();
	}


	@Override
	public List<String> categories() {
		List<String> categories=new ArrayList<>();
		List<CartItem> cart=getCart();
		for(CartItem temp: cart)
		{
			categories.add(resttemplate.getForObject("http://products-service/products/category/id="+temp.getProductId(), String.class));
		}
		
		return categories;
	}
	

}
