package com.cg.sunhome.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sunhome.Exception.MyException;
import com.cg.sunhome.dao.PriceRepository;
import com.cg.sunhome.dto.Price;

@Service
public class PriceServiceImpl implements PriceService {

	@Autowired
	PriceRepository priceDao;
	
	@Override
	public Double findPrice(int productId) {
		if(priceDao.existsById(productId))
		{
		return priceDao.getPriceById(productId);}
		else
			throw new MyException("Id not found");
	}

	@Override
	public Optional<Price> findPriceById(int id) {
		// TODO Auto-generated method stub
		return priceDao.findById(id);
	}
}
