package com.cg.sunhome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cg.sunhome.dto.Price;
import com.cg.sunhome.service.PriceService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@Api
public class PriceController {
	
	Logger logger = LoggerFactory.getLogger(PriceController.class);

	@Autowired
	PriceService priceService;
	
	@ApiOperation(value = "get Price on the basis of Product id")
	@GetMapping(value="/price/{id}")
	@ResponseBody
	@HystrixCommand(fallbackMethod="getPriceFail",commandKey="getPrice",groupKey="Lab2PriceService")
	public Double getPrice(@ApiParam(value="Product Id from which Price is generated")@PathVariable("id")int id)
	{
		logger.info("in get price");
		return priceService.findPrice(id);
	}
	public Double getPriceFail(int id)
	{
		return 0.0;
	}
	
	@GetMapping(value="/price/full/{id}")
	@ResponseBody
	public Optional<Price> getPriceById(@PathVariable("id")int id)
	{
		logger.info("get price by id");
		return priceService.findPriceById(id);
	}
	
}
