package com.cg.sunhome.service;

import java.util.Optional;

import com.cg.sunhome.dto.Price;

public interface PriceService {

	public Double findPrice(int productId);
	public Optional<Price> findPriceById(int id);
}
