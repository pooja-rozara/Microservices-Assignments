INSERT INTO Price (product_id,price) values(102,25000);
INSERT INTO Price (product_id,price) values(103,30000);
INSERT INTO Price (product_id,price) values(104,35000);