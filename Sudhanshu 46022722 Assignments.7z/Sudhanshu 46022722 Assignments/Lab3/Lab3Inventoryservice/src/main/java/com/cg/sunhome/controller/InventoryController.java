package com.cg.sunhome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sunhome.service.InventoryService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
public class InventoryController {
	@Autowired
	InventoryService invService;
	
	
	@ApiOperation(value = "get Stocks from Inventory")
	@GetMapping("/stocks/{productId}")
	@ResponseBody
	@HystrixCommand(fallbackMethod="getStocksFail",commandKey="getStocks",groupKey="Lab2InventoryService")
	public Integer getStocks(@ApiParam(value="Product Id from which stock is generated")@PathVariable("productId")int productId)
	{
		return invService.getStocks(productId);
	}
	public Integer getStocksFail(int productId)
	{
		return 0 ;
	}
	
}
