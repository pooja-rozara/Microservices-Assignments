package com.cg.sunhome.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cg.sunhome.dto.Product;
import com.cg.sunhome.service.ProductService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@Api
public class ProductController {
	
	Logger logger = LoggerFactory.getLogger(ProductController.class);
	
	@Autowired
	ProductService prodService;
	
	
	@ApiOperation(value = "search Product on the basis of Product Name")
	@GetMapping(value="/products/{name}")
	@ResponseBody
	public List<Product> searchProduct(@ApiParam(value="Product Name from which list of Product  is generated")@PathVariable("name")String name)
	{
		logger.info("in search product");
		return prodService.findByName(name);
	}
	
	@ApiOperation(value = "Get All Product")
	@GetMapping(value="/products")
	@ResponseBody
	public List<Product> getAllProducts()
	{
		logger.info("in get all products");
		return prodService.getAllProducts();
	}
	
	@ApiOperation(value = "Get Product Based On Id")
	@GetMapping(value="/products/id={id}")
	@ResponseBody
	@HystrixCommand(fallbackMethod="getProductFail",commandKey="getProduct",groupKey="Lab2ProductService")
	public Optional<Product> getProduct(@ApiParam(value="Product Id from which Product is generated")@PathVariable("id")int id)
	{
		logger.info("in get Product");
		return prodService.findById(id);
	}
	
	public Optional<Product> getProductFail(int id)
	{
		return null;
	}
	
	@ApiOperation(value = "Get Product Name based On id")
	@GetMapping(value="/products/name/{id}")
	@ResponseBody
	@HystrixCommand(fallbackMethod="getProductNameFail",commandKey="getProductName",groupKey="Lab2ProductService")
	public String getProductName(@ApiParam(value="Product Id from which Product name is generated")@PathVariable("id")int id)
	{
		logger.info("in get product name");
		return prodService.findNameById(id);
	}
	
	public String getProductNameFail(int id)
	{
		return "getProductNameFail";
	}
	
	@ApiOperation(value = "Get Product By Category")
	@GetMapping(value="/products/category={cat}")
	@ResponseBody
	public List<Product> getProductByCategory(@ApiParam(value="Product category from which list of Product is generated")@PathVariable("cat")String category)
	{
		logger.info("in get product by category");
		return prodService.getByCategory(category);
	}
	
	
}
