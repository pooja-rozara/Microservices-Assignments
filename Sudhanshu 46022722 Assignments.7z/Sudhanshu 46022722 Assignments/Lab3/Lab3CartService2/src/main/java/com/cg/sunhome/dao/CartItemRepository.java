package com.cg.sunhome.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.sunhome.dto.CartItem;

public interface CartItemRepository extends JpaRepository<CartItem, Integer>{

}
