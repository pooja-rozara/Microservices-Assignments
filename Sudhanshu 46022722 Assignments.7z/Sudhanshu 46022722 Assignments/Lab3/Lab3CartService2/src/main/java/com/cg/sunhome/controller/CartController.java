package com.cg.sunhome.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sunhome.dto.CartItem;
import com.cg.sunhome.service.CartService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


@Api
@RestController
public class CartController {

	Logger logger = LoggerFactory.getLogger(CartController.class);
	@Autowired
	CartService cartService;
	
	
	@ApiOperation(value = "Add to cart")
	@PostMapping(value="/cart")
	@ResponseBody
	@HystrixCommand(fallbackMethod="addingToCartFail",commandKey="addingToCart",groupKey="Lab2CartService")
	public String addToCart(@ApiParam(value="Cart value in JSON Format")@RequestBody CartItem item)
	{
		logger.info("in add to cart");
		return cartService.addToCart(item);
	}
	public String addingToCartFail(CartItem item)
	{
		return "Adding to cart is fail";
	}
	
	
}
