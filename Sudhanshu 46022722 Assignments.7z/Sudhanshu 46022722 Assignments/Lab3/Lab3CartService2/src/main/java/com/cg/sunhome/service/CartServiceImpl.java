package com.cg.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.sunhome.Exception.MyException;
import com.cg.sunhome.dao.CartItemRepository;
import com.cg.sunhome.dto.CartItem;

@Service
public class CartServiceImpl implements CartService{

	@Autowired
	CartItemRepository cartDao;
	
	@Autowired
	RestTemplate resttemplate;

		@Override
		public String addToCart(CartItem item) {
			double cartValue=0;
			String productName=null;
			if(item.getQuantity()<resttemplate.getForObject("http://inventory-service/stocks/"+item.getProductId(),Integer.class))
			{	cartDao.save(item);
				for(CartItem temp:cartDao.findAll())
				{
					cartValue+=(temp.getQuantity()*(resttemplate.getForObject("http://price-service/price/"+temp.getProductId(), Double.class)));
					productName=resttemplate.getForObject("http://products-service/products/name/"+temp.getProductId(), String.class);
				}
				return "Total Cart amount for"+productName+" is: Rs. "+cartValue;
				
			}
			else
				throw new MyException("Not sufficient Units");
		}
}
