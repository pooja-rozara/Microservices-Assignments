package com.cg.sunhome.service;

import com.cg.sunhome.dto.CartItem;

public interface CartService {
	
	public String addToCart(CartItem item);

}
