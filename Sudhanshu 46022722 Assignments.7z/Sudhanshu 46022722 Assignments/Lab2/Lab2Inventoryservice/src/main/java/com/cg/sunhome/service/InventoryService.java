package com.cg.sunhome.service;

public interface InventoryService {
	
	Integer getStocks(int productId);

}
