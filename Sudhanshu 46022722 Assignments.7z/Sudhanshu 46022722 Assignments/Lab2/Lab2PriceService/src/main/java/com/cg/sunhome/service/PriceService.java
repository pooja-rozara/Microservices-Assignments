package com.cg.sunhome.service;

public interface PriceService {

	public Double findPrice(int productId);
}
