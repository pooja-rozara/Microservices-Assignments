package com.cg.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sunhome.Exception.MyException;
import com.cg.sunhome.dao.PriceRepository;

@Service
public class PriceServiceImpl implements PriceService {

	@Autowired
	PriceRepository priceDao;
	
	@Override
	public Double findPrice(int productId) {
		if(priceDao.existsById(productId))
		{
		return priceDao.getPriceById(productId);}
		else
			throw new MyException("Id not found");
	}
}
