package com.cg.sunhome.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.sunhome.dto.Price;

public interface PriceRepository extends JpaRepository<Price, Integer> {

	@Query("select price.price from Price price where price.productId = :id")
	public double getPriceById(@Param("id") Integer id);
}
