package com.cg.sunhome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sunhome.service.PriceService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class PriceController {

	@Autowired
	PriceService priceService;
	
	@GetMapping(value="/price/{id}")
	@ResponseBody
	@HystrixCommand(fallbackMethod="getPriceFail",commandKey="getPrice",groupKey="Lab2PriceService")
	public Double getPrice(@PathVariable("id")int id)
	{
		return priceService.findPrice(id);
	}
	public Double getPriceFail(int id)
	{
		return 0.0;
	}
	
}
