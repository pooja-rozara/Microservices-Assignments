package com.cg.sunhome.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sunhome.Exception.MyException;
import com.cg.sunhome.dao.ProductRepository;
import com.cg.sunhome.dto.Product;
@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepository productDao;

	@Override
	public List<Product> getAllProducts() {
		return productDao.findAll();
	}

	@Override
	public List<Product> findByName(String name) {
		return productDao.findByProductNameContaining(name);
	}

	@Override
	public Optional<Product> findById(int id) {
		if(productDao.existsById(id))
		{
		return productDao.findById(id);}
		else
			 throw new MyException("Id not Found");
	}

	@Override
	public List<Product> getByCategory(String category) {
		
		return productDao.findProductByCategory(category);
	}

	@Override
	public String findNameById(int id) {
		if(productDao.existsById(id))
		{
		return productDao.findNameById(id);}
		else
			return "Id not Found";
	}

}
