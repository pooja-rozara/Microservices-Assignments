package com.sunhome.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunhome.dto.Stock;

public interface StockRepository extends JpaRepository<Stock, String> {
	
	@Query("Select s.productStock from Stock s where s.productName = :productName")
	Integer getStockByProductName(String productName);

}
