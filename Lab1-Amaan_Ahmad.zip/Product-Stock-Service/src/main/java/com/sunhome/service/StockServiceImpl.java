package com.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunhome.dao.StockRepository;
import com.sunhome.dto.Stock;

@Service
public class StockServiceImpl implements StockService{
    @Autowired
	private StockRepository stockRepo;
	@Override
	public Integer getProductStockbyName(String productName) {
		return stockRepo.getStockByProductName(productName);
	}

}
