package com.sunhome.service;

import com.sunhome.dto.Stock;

public interface StockService {

	Integer getProductStockbyName(String productName);
}
