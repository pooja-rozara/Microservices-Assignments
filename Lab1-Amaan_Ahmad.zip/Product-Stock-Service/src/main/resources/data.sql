insert into stock values('Samsung Note 8', 'Mobiles', 800);
insert into stock values('Xbox One', 'Gaming', 1600);
insert into stock values('Play Station 5', 'Gaming', 4000);
insert into stock values('Headphones', 'Accessories', 700);

