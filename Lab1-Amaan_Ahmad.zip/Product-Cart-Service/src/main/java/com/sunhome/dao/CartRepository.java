package com.sunhome.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunhome.dto.Cart;
import com.sunhome.dto.Product;

public interface CartRepository extends JpaRepository<Cart, String>{

}
