package com.sunhome.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Stock {
     
	@Id
	@Column(name ="product_name")
	private String productName;
	@Column(name ="product_category")
	private String productCategory;
	@Column(name ="product_stock")
	private int productStock;
	public Stock() {
		
	}
	public Stock(String productName, String productCategory, int productStock) {
		super();
		this.productName = productName;
		this.productCategory = productCategory;
		this.productStock = productStock;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public int getProductStock() {
		return productStock;
	}
	public void setProductStock(int productStock) {
		this.productStock = productStock;
	}
	
}
