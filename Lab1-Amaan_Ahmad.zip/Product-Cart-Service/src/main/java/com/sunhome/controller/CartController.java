package com.sunhome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.sunhome.dto.Cart;

import com.sunhome.service.CartService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;

@RestController
@RequestMapping("/cart")
@Api("Cart Service")
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@ApiOperation(value = "Add a product to cart")
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Successfully retrieved list"),
		    @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
		    @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
		    @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
	})
	@PostMapping("/product")
   public String addProductToCart(@RequestBody Cart cartItem) {
	  return cartService.addProductToCart(cartItem);
   }
	
	@GetMapping("/price/{productname}")
	public Float getProductPrice(@PathVariable("productname") String productname) {
		
		String url = "http://localhost:8083/price/"+productname;
		Float price = restTemplate.getForObject(url, Float.class);
		return price;
	}
}
