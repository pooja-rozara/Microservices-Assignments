package com.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sunhome.dao.CartRepository;
import com.sunhome.dto.Cart;
import com.sunhome.dto.Product;

@Service
public class CartServiceImpl implements CartService {
     
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Override
	public String addProductToCart(Cart cartItem) {
		String url = "http://localhost:8082/stock/productname="+cartItem.getProductName();
		Integer stock = restTemplate.getForObject(url, Integer.class);
	     if(stock>cartItem.getProductQuantity()) {
       cartRepository.save(cartItem);
       return "Product added Successfully";}
	     else
	    	 return "Insufficient stock";
	}
}
