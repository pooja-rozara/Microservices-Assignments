package com.sunhome.service;

import com.sunhome.dto.Cart;
import com.sunhome.dto.Product;

public interface CartService {

	String addProductToCart(Cart product);
}
