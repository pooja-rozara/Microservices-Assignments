insert into product values('110', 'Mobiles', 'Samsung Note 8');
insert into product values('130', 'Gaming', 'Xbox One');
insert into product values('140', 'Gaming', 'Play Station 5');
insert into product values('150', 'Accessories', 'Headphones');

