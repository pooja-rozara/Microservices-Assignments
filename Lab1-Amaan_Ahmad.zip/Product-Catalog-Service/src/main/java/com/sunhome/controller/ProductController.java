package com.sunhome.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.sunhome.dto.Price;
import com.sunhome.dto.Product;
import com.sunhome.dto.Stock;
import com.sunhome.service.ProductService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("product")
@Api("Product Catalog Service")
public class ProductController {
	
	@Autowired
 private ProductService productService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	//Consuming Product Stock Service
	@GetMapping("/stock/{productname}") 
	@ApiOperation(value = "Search for a Product stock")
	public Integer getProductStock(@PathVariable("productname") String productname) {
		String url = "http://localhost:8082/stock/productname="+productname;
		Integer stock = restTemplate.getForObject(url, Integer.class);
		return stock;
	}
	
	//Consuming Product Price Service
	@GetMapping("/price/{productname}")
	@ApiOperation(value = "Find Product price")
	public Float getProductPrice(@PathVariable("productname") String productname) {
		String url = "http://localhost:8083/price/"+productname;
		Float price = restTemplate.getForObject(url, Float.class);
		return price;
	}
	
	@GetMapping("/allproducts")
	@ApiOperation(value = "Fetch all the products")
	public List<Product> getAllProducts(){
		return productService.getAllProducts();
	}
	
	@GetMapping("/productid={productId}")
	@ApiOperation(value = "Search for a Product by Id")
	public Optional<Product> getProductById(@PathVariable("productId") String productId) {
		return productService.getProductById(productId);
	}
	
    @GetMapping("/productcategory={category}")
 	@ApiOperation(value = "Search for a Product by category")
	public List<Product> getProductByCategory(@PathVariable("category") String category){
    	 return productService.getProductByCategory(category);
     }
}
