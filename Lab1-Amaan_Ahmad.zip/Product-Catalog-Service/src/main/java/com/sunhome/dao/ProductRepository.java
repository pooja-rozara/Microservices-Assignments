package com.sunhome.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunhome.dto.Product;

public interface ProductRepository extends JpaRepository<Product, String>{
	
	@Query("Select p from Product p where p.productCategory=:category")
	public List<Product> getProductByCategory(String category);

}
