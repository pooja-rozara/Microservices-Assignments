package com.sunhome.service;
import java.util.List;
import java.util.Optional;

import com.sunhome.dto.Product;
public interface ProductService {
   
	List<Product>getAllProducts();

	Optional<Product> getProductById(String productId);

	List<Product> getProductByCategory(String category);
}
