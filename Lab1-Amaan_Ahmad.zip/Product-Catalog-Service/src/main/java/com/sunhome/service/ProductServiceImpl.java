package com.sunhome.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunhome.dao.ProductRepository;
import com.sunhome.dto.Product;

@Service
public class ProductServiceImpl implements ProductService {
     
	@Autowired
	ProductRepository productRepo;
	
	@Override
	public List<Product> getAllProducts() {
	  return productRepo.findAll();
	}

	@Override
	public Optional<Product> getProductById(String productId) {
		return productRepo.findById(productId);
	}

	@Override
	public List<Product> getProductByCategory(String category) {
		return productRepo.getProductByCategory(category);
	}
    
}
