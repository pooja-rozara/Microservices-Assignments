insert into price values('110', 'Samsung Note 8', 50000.0);
insert into price values('130', 'Xbox One', 35000.0);
insert into price values('140', 'Play Station 5', 40000.0);
insert into price values('150', 'Headphones', 5000.0);
