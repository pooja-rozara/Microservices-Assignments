package com.sunhome.service;

import com.sunhome.dto.Price;

public interface ProductPriceService {
	Float getProductPriceByName(String productName);

}
