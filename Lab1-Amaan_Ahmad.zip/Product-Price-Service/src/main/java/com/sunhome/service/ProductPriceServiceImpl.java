package com.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunhome.dao.ProductPriceRepository;
import com.sunhome.dto.Price;

@Service
public class ProductPriceServiceImpl implements ProductPriceService{

	@Autowired
	private ProductPriceRepository prodPriceRepo;
	@Override
	public Float getProductPriceByName(String productName) {
		return prodPriceRepo.getProductPriceByName(productName);
	}

}
