package com.sunhome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunhome.dto.Price;
import com.sunhome.service.ProductPriceService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/price")
@Api("Product Catalog Service")
public class PriceController {
    
	@Autowired
	private ProductPriceService prodPriceService;
	
	@RequestMapping("/{productname}")
	@ApiOperation(value = "Search for Product Price")
	public Float getPriceByProdName(@PathVariable("productname") String productName) {
		return prodPriceService.getProductPriceByName(productName);
	}
}
