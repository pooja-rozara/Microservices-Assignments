package com.sunhome.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunhome.dto.Price;

public interface ProductPriceRepository extends JpaRepository<Price, String>{

	@Query("Select p.productPrice from Price p where productName=:productName")
	Float getProductPriceByName(String productName);

}
