package com.sunhome.cotroller;

import java.util.Set;

import org.hibernate.cache.spi.support.AbstractReadWriteAccess.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sunhome.dto.CartItem;
import com.sunhome.service.CartService;

@RestController
public class CartController {
	@Autowired
	CartService cartService;
	
	@PostMapping(value="/cart/")
	@ResponseBody
	public String addToCart(@RequestBody CartItem item)
	{
		return cartService.addToCart(item);
	}
	
	
	/*
	 * @GetMapping(value="/cart") public Set<Item>
	 * getItemsInCart(@RequestParam("id") int cartId) { return
	 * cartService.getCartWithId(cartId).getItems(); }
	 * 
	 */
}
