package com.sunhome.service;

import com.sunhome.dto.CartItem;

public interface CartService {
	
	String addToCart(CartItem item);
	
	public CartItem getCartWithId(int cartId);

}
