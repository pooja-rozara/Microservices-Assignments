package com.cg.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.sunhome.Exception.MyException;
import com.cg.sunhome.dao.CartItemRepository;
import com.cg.sunhome.dto.CartItem;

@Service
public class CartServiceImpl implements CartService{

	@Autowired
	CartItemRepository cartDao;

		@Override
		public String addToCart(CartItem item) {
			double cartValue=0;
			String productName=null;
			if(item.getQuantity()<new RestTemplate().getForObject("http://localhost:8081/stocks/"+item.getProductId(),Integer.class))
			{	cartDao.save(item);
				for(CartItem temp:cartDao.findAll())
				{
					cartValue+=(temp.getQuantity()*(new RestTemplate().getForObject("http://localhost:8083/price/"+temp.getProductId(), Double.class)));
					productName=new RestTemplate().getForObject("http://localhost:8082/products/name/"+temp.getProductId(), String.class);
				}
				return "Total Cart amount for"+productName+" is: Rs. "+cartValue;
				
			}
			else
				throw new MyException("Not sufficient Units");
		}
}
