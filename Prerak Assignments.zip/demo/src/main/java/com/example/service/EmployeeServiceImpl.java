package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.EmployeeRepository;
import com.example.dto.Employee;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeRepository empDao;

	@Override
	public List<Employee> showEmployee() {
		
		return empDao.findAll();
	}

	@Override
	public void addEmployee(Employee employee) {
	
		empDao.save(employee);
	}

}
