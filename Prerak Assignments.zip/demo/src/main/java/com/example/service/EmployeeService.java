package com.example.service;

import java.util.List;

import com.example.dto.Employee;

public interface EmployeeService {
	public List<Employee> showEmployee();
	public void addEmployee(Employee employee);
}
