package com.sunhome.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sunhome.dto.Product;
import com.sunhome.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	ProductService prodService;
	
	@GetMapping(value="/all")
	@ResponseBody
	public List<Product> getAllProducts()
	{
		return prodService.getAllProducts();
	}
	
	@GetMapping(value="/name/{name}")
	@ResponseBody
	public List<Product> searchProduct(@PathVariable("name")String name)
	{
		return prodService.findByName(name);
	}
	
	@GetMapping(value="/category/{category}")
	@ResponseBody
	public List<Product> getProductByCategory(@PathVariable("category")String category)
	{
		return prodService.getByCategory(category);
	}
	
	@GetMapping(value="/price/{id}")
	@ResponseBody
	public double getProductPrice(@PathVariable("id")Integer id)
	{
		return prodService.findProductPrice(id);
	}
	
	@GetMapping(value="/id/{id}")
	@ResponseBody
	public Optional<Product> getProductById(@PathVariable("id")Integer id)
	{
		return prodService.findById(id);
	}
	
}
