package com.sunhome.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunhome.dao.ProductRepository;
import com.sunhome.dto.Product;
@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepository productRepo;

	@Override
	public List<Product> getAllProducts() {
		return productRepo.findAll();
	}

	@Override
	public List<Product> findByName(String name) {
		return productRepo.findByProductName(name);
	}

	@Override
	public double findProductPrice(int productId) {
		return productRepo.getPriceById(productId);
	}

	@Override
	public Optional<Product> findById(int id) {
		return productRepo.findById(id);
	}

	@Override
	public List<Product> getByCategory(String category) {
		return productRepo.findProductByCategory(category);
	}

}
