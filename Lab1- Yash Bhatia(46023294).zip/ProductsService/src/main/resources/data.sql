INSERT INTO Product (product_id,product_name,price,category) values(109,'OnePlus',50000,'Mobile');
INSERT INTO Product (product_id,product_name,price,category) values(106,'Sony',22000,'TV');
INSERT INTO Product (product_id,product_name,price,category) values(13,'iPhone',65000,'Mobile');
INSERT INTO Product (product_id,product_name,price,category) values(14,'Oppo',20000,'Mobile');