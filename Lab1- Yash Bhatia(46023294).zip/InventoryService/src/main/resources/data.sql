INSERT INTO inventory(product_id,available_units) values (109,57); 
INSERT INTO inventory(product_id,available_units) values (106,50); 
INSERT INTO inventory(product_id,available_units) values (13,60); 
INSERT INTO inventory(product_id,available_units) values (14,46); 