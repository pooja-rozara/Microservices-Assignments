package com.sunhome.service;

public interface InventoryService {
	
	int getStock(int productId);

}
