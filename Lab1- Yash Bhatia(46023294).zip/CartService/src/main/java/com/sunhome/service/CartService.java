package com.sunhome.service;

import org.springframework.stereotype.Service;

import com.sunhome.dto.Cart;

@Service
public interface CartService {
		String addToCart(Cart item);
}
