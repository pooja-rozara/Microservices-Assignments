package com.sunhome.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sunhome.dao.CartRepository;
import com.sunhome.dto.Cart;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	CartRepository cartRepo;
	
	@Override
	public String addToCart(Cart item) {
		double cartProductPrice = 0;
		if(item.getQuantity()< new RestTemplate().getForObject("http://localhost:8081/inventory/stocks/" + item.getProductId(), Integer.class)) {
			cartRepo.save(item);
			List<Cart> cartItems = (List<Cart>)cartRepo.findAll();
			for(Cart product : cartItems) {
				cartProductPrice+=(product.getQuantity()*(new RestTemplate().getForObject("http://localhost:8082/product/price/"
			+ product.getProductId(), Double.class)));
			}
		return "Total amount= " +  cartProductPrice;
		
		}
		else {
			return "Not enough stock of product with ProductId = " + item.getProductId();
		}
	}

}
