package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.dao.CartRepository;
import com.cg.dto.Cart;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	CartRepository repository;
	@Override
	public String addToCart(Cart cart) {
		// TODO Auto-generated method stub
		double cartValue=0;
		if(cart.getQuantity()<new RestTemplate().getForObject("http://localhost:8083/stocks/"+cart.getProductId(),Integer.class))
		{	
			repository.save(cart);
			cartValue+=(cart.getQuantity()*(new RestTemplate().getForObject("http://localhost:8085/productPrice/id="+cart.getProductId(), Double.class)));
			/*
			 * for(Cart temp:repository.findAll()) { cartValue+=(temp.getQuantity()*(new
			 * RestTemplate().getForObject("http://localhost:8085/productPrice/id="+temp.
			 * getProductId(), Double.class))); }
			 */
			String prodList=(new RestTemplate().getForObject("http://localhost:8082/product/catId="+cart.getProductId(), String.class));
			return "Total Cart amount is: Rs. "+cartValue+"\n Recommended Products Are: "+prodList;
			
		}
		else
			return "Not Sufficient Stocks present";
	}
	@Override
	public String getRecommendation(int productId) {
		// TODO Auto-generated method stub
		System.out.println("Entered");
		String prodList=(new RestTemplate().getForObject("http://localhost:8082/product/catId="+productId, String.class));
		
		return prodList;
	}

}
