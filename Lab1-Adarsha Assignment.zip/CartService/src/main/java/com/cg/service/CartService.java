package com.cg.service;

import java.util.List;

import com.cg.dto.Cart;

public interface CartService {
	public String addToCart(Cart cart);
	public String getRecommendation(int productId);
}
