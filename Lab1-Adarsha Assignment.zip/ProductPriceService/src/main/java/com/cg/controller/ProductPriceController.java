package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.ProductPrice;
import com.cg.service.ProductPriceService;

@RestController
public class ProductPriceController {
	
	@Autowired
	ProductPriceService productPriceService;
	
	@PostMapping(value="productPrice/save/")
	@ResponseBody
	public List<ProductPrice> addproductPrice(@RequestBody ProductPrice product)
	{
		return productPriceService.addProductPrice(product);
	}
	
	@GetMapping(value="/productsPrice")
	@ResponseBody
	public List<ProductPrice> getAllProductsData()
	{
		return productPriceService.getAllProducts();
	}
	
	@GetMapping(value="/productPrice/id={id}")
	@ResponseBody
	public double getProductPrice(@PathVariable("id") int productId)
	{
		return productPriceService.findPrice(productId);
	}
}
