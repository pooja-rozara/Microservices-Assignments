package com.cg.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ProductPrice {
	@Id
	int productId;
	double productPrice;
	
	
	public ProductPrice(int productId, double productPrice) {
		super();
		this.productId = productId;
		this.productPrice = productPrice;
	}
	public ProductPrice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "ProductPrice [productId=" + productId + ", productPrice=" + productPrice + "]";
	}
	
	
}
