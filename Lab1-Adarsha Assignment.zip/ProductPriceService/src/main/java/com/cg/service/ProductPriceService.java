package com.cg.service;

import java.util.List;

import com.cg.dto.ProductPrice;

public interface ProductPriceService {
	public List<ProductPrice> addProductPrice(ProductPrice prod);
	public List<ProductPrice> getAllProducts();
	public double findPrice(int productId);
}
