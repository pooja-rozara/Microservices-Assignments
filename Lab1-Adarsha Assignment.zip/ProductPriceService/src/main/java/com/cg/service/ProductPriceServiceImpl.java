package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ProductPriceRepository;
import com.cg.dto.ProductPrice;

@Service
public class ProductPriceServiceImpl implements ProductPriceService{

	@Autowired
	ProductPriceRepository repository;
	@Override
	public List<ProductPrice> addProductPrice(ProductPrice prod) {
		// TODO Auto-generated method stub
		repository.save(prod);
		return (List<ProductPrice>) prod;
	}

	@Override
	public List<ProductPrice> getAllProducts() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public double findPrice(int productId) {
		// TODO Auto-generated method stub
		return repository.getProductPriceById(productId);
	}

}
