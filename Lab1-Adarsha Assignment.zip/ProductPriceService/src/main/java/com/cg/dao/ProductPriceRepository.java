package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.dto.ProductPrice;

@Repository
public interface ProductPriceRepository extends JpaRepository<ProductPrice,Integer>{
	
	@Query("select product.productPrice from ProductPrice product where product.productId = :id")
	public double getProductPriceById(@Param("id") Integer id);
}
