INSERT INTO Product_Price(product_id,product_price) values (101,25000); 
INSERT INTO Product_Price(product_id,product_price) values (102,35000); 
INSERT INTO Product_Price(product_id,product_price) values (103,45000); 