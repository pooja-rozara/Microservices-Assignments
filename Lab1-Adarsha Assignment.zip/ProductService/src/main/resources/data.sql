INSERT INTO Product (product_id,product_name,product_category) values(101,'Redmi','Mobile');
INSERT INTO Product (product_id,product_name,product_category) values(102,'samsung','TV');
INSERT INTO Product (product_id,product_name,product_category) values(103,'Sony','Refrigrator')