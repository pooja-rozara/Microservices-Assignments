package com.cg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.Product;
import com.cg.service.ProductService;
import com.cg.service.ProductServiceImpl;

@RestController
public class ProductController {
	@Autowired
	ProductService productService;
	
	@GetMapping(value="/products")
	@ResponseBody
	public List<Product> getAllProducts()
	{
		return productService.getAllProducts();
	}
	
	@GetMapping(value="/products/{id}")
	@ResponseBody
	public Optional<Product> findById(@PathVariable String id)
	{
		return productService.findById(Integer.parseInt(id));
	}
	
	@GetMapping(value="/product/search={name}")
	@ResponseBody
	public List<Product> searchByName(@PathVariable String name)
	{
		List<Product> res=productService.findByName(name);
		for(Product p:res)
		{
			System.out.println("Searching"+res);
		}
		return productService.findByName(name);
	}
	
	@GetMapping(value="/product/category={category}")
	@ResponseBody
	public List<Product> getCategory(@PathVariable String category)
	{
		List<Product> li=productService.getByCategory(category);
		for(Product p:li)
		{
			System.out.println("Category searching: "+p);
		}
		return productService.getByCategory(category);
	}
	
	@GetMapping(value="/product/catId={id}")
	@ResponseBody
	public String getCategoryById(@PathVariable String id)
	{
		String category=productService.findCategory(Integer.parseInt(id));
		List<Product> prodList=productService.getByCategory(category);
		String str="";
		for(Product p:prodList)
		{
			str=str+p+"\n";
		}
		return str;
	}
}
