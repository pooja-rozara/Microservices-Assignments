package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ProductRepository;
import com.cg.dto.Product;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductRepository repository;
	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		List<Product> productList=repository.findAll();
		return productList;
	}

	@Override
	public Optional<Product> findById(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id);
	}

	@Override
	public List<Product> findByName(String name) {
		// TODO Auto-generated method stub
		return repository.findByProductNameContaining(name);
	}

	@Override
	public List<Product> getByCategory(String category) {
		// TODO Auto-generated method stub
		return repository.findByProductCategory(category);
	}

	@Override
	public String findCategory(int productId) {
		// TODO Auto-generated method stub
		return repository.getProductCategoryById(productId);
	}

}
