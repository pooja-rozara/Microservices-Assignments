package com.cg.InventoryService.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.InventoryService.dao.InventoryRepository;

@Service
public class InventoryServiceImpl implements InventoryService {

	@Autowired
	InventoryRepository repository;
	@Override
	public int getStocks(int productId) {
		// TODO Auto-generated method stub
		return repository.getStockByProductId(productId);
	}

}
