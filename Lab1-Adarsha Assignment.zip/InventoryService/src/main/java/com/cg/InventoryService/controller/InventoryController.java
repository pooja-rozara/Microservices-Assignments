package com.cg.InventoryService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.InventoryService.service.InventoryService;

@RestController
public class InventoryController {
	@Autowired
	InventoryService inventoryService;
	
	@GetMapping("/stocks/{id}")
	@ResponseBody
	public int getStocks(@PathVariable("id")String productId)
	{
		return inventoryService.getStocks(Integer.parseInt(productId));
	}
}
