package com.cg.InventoryService.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.InventoryService.dto.Inventory;

@Repository
public interface InventoryRepository extends JpaRepository<Inventory,Integer>{
	@Query("SELECT inv.availableUnits from Inventory inv where inv.productId= :id")
	int getStockByProductId(@Param("id")int productId);
}
