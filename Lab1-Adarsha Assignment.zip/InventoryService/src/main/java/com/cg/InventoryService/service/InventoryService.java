package com.cg.InventoryService.service;

public interface InventoryService {
	int getStocks(int productId);
}
