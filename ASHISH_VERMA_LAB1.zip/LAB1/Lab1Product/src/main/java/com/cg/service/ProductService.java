package com.cg.service;

import java.util.List;
import java.util.Optional;

import com.cg.dto.Product;

public interface ProductService {
	public Optional<Product> getProductById(int id);
	public List<Product> getAllProducts();
	public List<Product> getProductsByCategory(String Category);
	public List<Product> findByName(String name);
	public double findPrice(int productId);
}
