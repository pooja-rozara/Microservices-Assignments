package com.cg.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.Product;
import com.cg.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	@Autowired
	ProductService prodService;
	
	@GetMapping(value="/search={name}")
	@ResponseBody
	public List<Product> searchProduct(@PathVariable("name")String name)
	{
		return prodService.findByName(name);
	}
	
	
	@GetMapping(value="/all")
	@ResponseBody
	public List<Product> getAllProducts()
	{
		return prodService.getAllProducts();
	}
	
	@GetMapping(value="/{id}")
	@ResponseBody
	public Optional<Product> getProduct(@PathVariable("id")String id)
	{
		return prodService.getProductById(Integer.parseInt(id));
	}
	
	@GetMapping(value="/category={category}")
	@ResponseBody
	public List<Product> getProductByCategory(@PathVariable("category")String category)
	{
		return prodService.getProductsByCategory(category);
	}
	@GetMapping(value="/price/id={id}")
	@ResponseBody
	public double getPrice(@PathVariable("id")String id)
	{
		return prodService.findPrice(Integer.parseInt(id));
	}
	
	
	
}
