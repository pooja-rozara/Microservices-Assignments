package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ProductRepository;
import com.cg.dto.Product;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductRepository prodRepo;

	@Override
	public Optional<Product> getProductById(int id) {
		return prodRepo.findById(id);
	}

	@Override
	public List<Product> getAllProducts() {
		return prodRepo.findAll();
	}

	@Override
	public List<Product> getProductsByCategory(String category) {
		return prodRepo.findProductByCategory(category);
	}

	@Override
	public List<Product> findByName(String name) {
		return prodRepo.findByProductNameContaining(name);
	}

	@Override
	public double findPrice(int productId) {
		return prodRepo.getPriceById(productId);
	}

}
