package com.cg.dto;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Stock {
	@Id
	int productId;
	int availableUnits;
	
	public Stock() {
		super();
	}
	public Stock(int productId, int availableUnits) {
		super();
		this.productId = productId;
		this.availableUnits = availableUnits;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getAvailableUnits() {
		return availableUnits;
	}
	public void setAvailableUnits(int availableUnits) {
		this.availableUnits = availableUnits;
	}

}
