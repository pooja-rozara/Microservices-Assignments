package com.cg.service;

import com.cg.dto.Stock;

public interface StockService {

	public int getStocks(int productId);
	public Stock addStocks(Stock stock);
}
