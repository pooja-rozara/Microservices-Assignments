package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.StockRepository;
import com.cg.dto.Stock;

@Service
public class StockServiceImpl implements StockService{

	@Autowired
	StockRepository stockRepo;
	
	@Override
	public int getStocks(int productId) {
		return stockRepo.getStockById(productId) ;
	}

	@Override
	public Stock addStocks(Stock stock) {
		if(stockRepo.existsById(stock.getProductId())) {
		int previosStock=stockRepo.getStockById(stock.getProductId());
		int newStock=stock.getAvailableUnits();
		stock.setAvailableUnits(previosStock+newStock);
		return stockRepo.save(stock);}
		else
			return stockRepo.save(stock);
	}
	
}
