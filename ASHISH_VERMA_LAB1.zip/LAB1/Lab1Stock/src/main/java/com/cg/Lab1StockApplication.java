package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab1StockApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab1StockApplication.class, args);
	}

}
