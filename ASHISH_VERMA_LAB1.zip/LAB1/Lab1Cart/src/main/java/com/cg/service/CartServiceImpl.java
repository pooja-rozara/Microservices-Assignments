package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.dao.CartRepository;
import com.cg.dto.Cart;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	CartRepository cartRepo;
	
	@Override
	public String addToCart(Cart item) {
		double cartValue=0;
		if(item.getQuantity()<new RestTemplate().getForObject("http://localhost:8081/stocks/id="+item.getProductId(),Integer.class))
		{	cartRepo.save(item);
			for(Cart temp:cartRepo.findAll())
			{
				cartValue+=(temp.getQuantity()*(new RestTemplate().getForObject("http://localhost:8082/products/price/id="+temp.getProductId(), Double.class)));
			}
			return "Total Cart amount is: Rs. "+cartValue;
			
		}
		else
			return "Not sufficient Units";
	}
}
