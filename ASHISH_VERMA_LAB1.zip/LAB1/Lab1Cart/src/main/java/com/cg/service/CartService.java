package com.cg.service;

import com.cg.dto.Cart;

public interface CartService {
	
	String addToCart(Cart item);

}
